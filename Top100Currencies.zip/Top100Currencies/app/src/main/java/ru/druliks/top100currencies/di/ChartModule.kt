package ru.druliks.top100currencies.di

import dagger.Module

@Module
class ChartModule {
}